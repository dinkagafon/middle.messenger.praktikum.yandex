type Listener = (store: Indexed) => void;

export default Listener;
