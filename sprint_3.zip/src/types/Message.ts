type Message = {
  time: string,
  type: string,
  user_id: number,
  content: string,
  id: number,
};

export default Message;
