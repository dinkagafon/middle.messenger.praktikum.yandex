import Block from '../utils/Block';

type BlockEvent = (e?: MouseEvent | KeyboardEvent, comp?: Block) => void;

export default BlockEvent;
