type Indexed = {
  [index: string]: any
};

export default Indexed;
