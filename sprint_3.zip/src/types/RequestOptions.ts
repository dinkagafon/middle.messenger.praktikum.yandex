interface RequestOptions<LoginRequest> {
  data?: LoginRequest,
  method: string,
}
export default RequestOptions;
