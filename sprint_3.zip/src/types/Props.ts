import Events from './Events';

type Props = {
  [index: string]: any,
  events?: Events
};

export default Props;
