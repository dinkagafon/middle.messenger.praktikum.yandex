type ApiError = {
  reason: string
};

export default ApiError;
