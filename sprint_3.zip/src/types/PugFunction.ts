type PugFunction = (ctx: Record<string, any>) => string;

export default PugFunction;
