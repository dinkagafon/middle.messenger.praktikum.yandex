type Attrs = {
  [index: string]: string
};

export default Attrs;
