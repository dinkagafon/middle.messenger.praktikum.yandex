import Block from '../utils/Block';

type Components = {
  [index: string]: Block
};

export default Components;
