type LoginRequest = {
  login: string,
  password: string
};

export default LoginRequest;
