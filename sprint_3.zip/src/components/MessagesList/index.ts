import MessagesList from './MessagesList';

export default MessagesList;
