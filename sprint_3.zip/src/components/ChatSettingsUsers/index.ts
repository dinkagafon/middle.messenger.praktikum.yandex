import ChatSettingsUsers from './ChatSettingsUsers';

export default ChatSettingsUsers;
