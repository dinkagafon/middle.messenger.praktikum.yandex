import ProfileEditor from './ProfileEditor';

export default ProfileEditor;
