import ChatWindow from './ChatWindow';

export default ChatWindow;
