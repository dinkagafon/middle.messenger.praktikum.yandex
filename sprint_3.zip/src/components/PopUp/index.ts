import PopUp from './PopUp';

export default PopUp;
