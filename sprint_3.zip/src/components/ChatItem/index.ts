import ChatItem from './ChatItem';

export default ChatItem;
