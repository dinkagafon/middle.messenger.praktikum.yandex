import ChatSettings from './ChatSettings';

export default ChatSettings;
