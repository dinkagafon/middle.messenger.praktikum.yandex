import ChatsBar from './ChatsBar';

export default ChatsBar;
