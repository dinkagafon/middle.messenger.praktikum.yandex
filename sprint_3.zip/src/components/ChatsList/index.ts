import ChatsList from './ChatsList';

export default ChatsList;
