const setChatSettingsPopUpActive = () => ({
  type: 'popUp/SETCHATSETTINGACTIVE',
});

export default setChatSettingsPopUpActive;
