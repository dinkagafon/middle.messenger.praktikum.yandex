const setChatNamePopUpDisable = () => ({
  type: 'popUp/SETCHATNAMEDISABLE',
});

export default setChatNamePopUpDisable;
