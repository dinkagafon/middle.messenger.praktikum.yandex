const clearPasswordError = () => ({
  type: 'errors/CLEARPASSWORD',
});

export default clearPasswordError;
