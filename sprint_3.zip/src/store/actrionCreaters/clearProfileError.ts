const clearProfileError = () => ({
  type: 'errors/CLEARPROFILE',
});

export default clearProfileError;
