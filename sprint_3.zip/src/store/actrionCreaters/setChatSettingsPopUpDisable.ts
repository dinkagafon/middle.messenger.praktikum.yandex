const setChatSettingsPopUpDisable = () => ({
  type: 'popUp/SETCHATSETTINGDISABLE',
});

export default setChatSettingsPopUpDisable;
