const setChatNamePopUpActive = () => ({
  type: 'popUp/SETCHATNAMEACTIVE',
});

export default setChatNamePopUpActive;
