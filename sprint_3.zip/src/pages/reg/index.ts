import Reg from './Reg';

export default Reg;
