import Error404 from './Error404';

export default Error404;
