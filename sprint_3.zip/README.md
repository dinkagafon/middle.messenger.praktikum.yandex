https://github.com/dinkagafon/middle.messenger.praktikum.yandex/pull/4
Это учебный мессенджер в рамках программы Яндекс Практикума.
Во втором спринте добавлна блочная структура.

yarn dev - запуска сервера Parcel
yarn start - запуск сервера Express, который раздает статику из build
yarn build - сборка проекта

Ссылка на Netlify - https://blissful-meitner-f351f8.netlify.app/
Ссылка на фигму - https://www.figma.com/file/xyVhHRFqIzPWWTwhSEKHpE/Untitled?node-id=0%3A1